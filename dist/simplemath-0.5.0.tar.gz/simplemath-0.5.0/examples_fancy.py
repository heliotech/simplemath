#!/usr/bin/python3
# -*- coding: utf-8 -*-

# examples_fancy.py

from examples import demo_fancy

demo_fancy.addition()
demo_fancy.subtraction()
demo_fancy.multiplication()
demo_fancy.division()
