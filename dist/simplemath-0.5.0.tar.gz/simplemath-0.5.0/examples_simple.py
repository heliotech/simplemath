#!/usr/bin/python3
# -*- coding: utf-8 -*-

# examples_simple.py

from examples import demo_simple

demo_simple.addition()
demo_simple.subtraction()
demo_simple.multiplication()
demo_simple.division()
