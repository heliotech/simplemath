from distutils.core import setup


setup(name='simplemath',
      version='0.5.0',
      description='Simple algebra with python',
      py_modules=['simplemath'],
      author=['khaz'],
      author_email='pykhaz@o2.pl'
      )
